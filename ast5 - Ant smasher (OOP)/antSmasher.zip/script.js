var canvas = document.getElementsByTagName('canvas')[0];
var c = canvas.getContext('2d');

var container = {x:0,y:0,width:1200,height:600};

// var circles = [{x:400,y:400,r:50,color:25,vx:6,vy:10},
//             {x:500,y:300,r:100,color:125,vx:2,vy:-8},
//             {x:800,y:350,r:25,color:285,vx:20,vy:-20},
//             {x:800,y:300,r:75,color:325,vx:13,vy:-8},
//             {x:400,y:200,r:20,color:175,vx:-24,vy:-6}   
// ];
xPalette = [200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800];
yPalette = [200, 250, 300, 350, 400, 450];
radiusPalette = [25, 30, 32, 34, 36, 38, 40];
colorPalette = [25, 50, 75, 100, 125, 150, 175, 200, 175];
// xVelocityPalette = [-20, -16, -12, -8, -4, 4, 8, 12, 16, 20];
// yVelocityPalette = [-20, -16, -12, -8, -4, 4, 8, 12, 16, 20];
velocityPalette = [-8, -4, 4, 8];

function circleMake(){
    this.x = xPalette[Math.floor(Math.random()*xPalette.length)];
    this.y = yPalette[Math.floor(Math.random()*yPalette.length)];
    this.r = radiusPalette[Math.floor(Math.random()*radiusPalette.length)];
    this.color = colorPalette[Math.floor(Math.random()*colorPalette.length)];
    this.vx = velocityPalette[Math.floor(Math.random()*velocityPalette.length)];
    this.vy = velocityPalette[Math.floor(Math.random()*velocityPalette.length)];

    this.circleInit = function(){
        c.fillStyle = 'hsl(' + this.color + ',100%,50%)';
        c.beginPath();
        c.arc(this.x,this.y,this.r,0,2*Math.PI,false);
        c.fill();
        // console.log("Entered");
    }

}

var noOfCircles = 50;
var circles = [];
for(var i=0; i<noOfCircles; i++){
    circles.push(new circleMake());
}
console.log(circles);

function draw(){
    c.fillStyle = 'black';
    c.strokeStyle = 'black';
    c.fillRect(container.x,container.y,container.width,container.height);
    //c.clearRect(container.x,container.y,container.width,container.height);
    //c.strokeRect(container.x,container.y,container.width,container.height);
    var cir1 = new circleMake();
    var cir2 = new circleMake();
    


    for(var i=0; i <circles.length; i++){
        c.fillStyle = 'hsl(' + circles[i].color + ',100%,50%)';
        c.beginPath();
        c.arc(circles[i].x,circles[i].y,circles[i].r,0,2*Math.PI,false);
        c.fill();


        if((circles[i].x + circles[i].vx + circles[i].r > container.x + container.width) || (circles[i].x - circles[i].r + circles[i].vx < container.x)){
        circles[i].vx = - circles[i].vx;
        }
        if((circles[i].y + circles[i].vy + circles[i].r > container.y + container.height) || (circles[i].y - circles[i].r + circles[i].vy < container.y)){
         circles[i].vy = - circles[i].vy;
        }
        circles[i].x +=circles[i].vx;
        circles[i].y +=circles[i].vy;
    }
    // requestAnimationFrame(draw);

}


// requestAnimationFrame(draw);


// }

// //invoke function init once document is fully loaded
// window.addEventListener('load',init,false);

// }());  //self invoking function

function animate(){
    
    c.clearRect(container.x,container.y,container.width,container.height);
    draw();
    requestAnimationFrame(animate);
}
animate();